//sets up variable lists based on database data
var allWords = getColumn("Words", "Word");
var wordLen = getColumn("Words", "Length");
var validWords = getColumn("5-Words","word");
var fiveWords = [];


//filters big word list to only get words with 5 letters
for (var i = 0; i < allWords.length; i++){
  if (wordLen[i] == 5){
    appendItem(fiveWords,allWords[i]);
  }
}


//selects a random 5 letter word as the answer when the lplay button is hit
var winWord;
onEvent("playButton", "click", function( ) {
  winWord = fiveWords[randomNumber(0,fiveWords.length)];
  setScreen("playScreen");
});


//gets the user guess, if it's a valid answer, checks the corresponding letters when submit button is clicked
var wordRowCount = 1;
onEvent("guessButton", "click", function( ) {
  getWord(wordRowCount);
  validWord();
  checkWin();
  wordRowCount++;
  console.log(winWord);
  console.log(guessWord);
  guessWord = "";
});


//gets the user inputted word from the respective row
var guessWord = "";
function getWord(row){
   for (var i = 1; i < 6; i++){
     guessWord = guessWord + getText("R" + row + "L" + i);
   }
}


//checks to see what from the guess matches the answer
function checkWord(row,guess){
  for (var i = 1; i < 6; i++){
    if (guess[i-1] == winWord[i-1]){
      setProperty("R" + row + "L" + i,"background-color","green");
    } else if (guess[i-1] == winWord[0]){
      setProperty("R" + row + "L" + i,"background-color","yellow");
    } else if (guess[i-1] == winWord[1]){
      setProperty("R" + row + "L" + i,"background-color","yellow");
    } else if (guess[i-1] == winWord[2]){
      setProperty("R" + row + "L" + i,"background-color","yellow");
    } else if (guess[i-1] == winWord[3]){
      setProperty("R" + row + "L" + i,"background-color","yellow");
    } else if (guess[i-1] == winWord[4]){
      setProperty("R" + row + "L" + i,"background-color","yellow");
    } else {
      setProperty("R" + row + "L" + i,"background-color",rgb(100, 100, 100));
    }
  }
  playSound("assets/category_bell/quiet_bell_notification.mp3");
}


//checks to see if guess is an actual 5 letter word
function validWord( ){
  var val;
  for (var i = 0; i < validWords.length; i++){
    if (guessWord == validWords[i]){
      val = true;
      checkWord(wordRowCount,guessWord);
    }
  }
  if (val == true){
    setText("checkText","Enter a word and click the button to make your guess");
    } else {
    setText("checkText","Invalid Word");
    playSound("assets/category_hits/vibrant_game_game_box_hit_1.mp3");
    wordRowCount--;
    }
}


//checks if guess is the answer
function checkWin( ){
  if (guessWord == winWord){
    playSound("assets/category_achievements/peaceful_win_6.mp3");
    setText("endArea","Good job, you guessed the word in only " + wordRowCount + "/6 tries!");
    setScreen("endScreen");
  } else if (wordRowCount == 6){
    setImageURL("endImage1","https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Skull_and_Crossbones.svg/510px-Skull_and_Crossbones.svg.png");
    setImageURL("endImage2","https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Skull_and_Crossbones.svg/510px-Skull_and_Crossbones.svg.png");
    showElement("endBloodPic");
    playSound("assets/category_transition/negative_game_over_whoosh.mp3");
    setScreen("endScreen");
    setText("endArea","You lose! The correct word was " + winWord + ". Better luck next time!");
  }
}


/* Citations
rosePic {image}, endImage1 {image}, endImage2 {image} - http://assets.stickpng.com/thumbs/580b585b2edbce24c47b2690.png 
bloodPic {image}, endBloodPic {image} - https://jkfranko.com/wp-content/uploads/2018/10/cropped-blood-splatter-texture-png-5.png
skullPic {image}, endImage1, endImage2 - https://purepng.com/public/uploads/large/purepng.com-skullskullvertebratesfacehuman-skull-1421526968344k1p20.png
*/